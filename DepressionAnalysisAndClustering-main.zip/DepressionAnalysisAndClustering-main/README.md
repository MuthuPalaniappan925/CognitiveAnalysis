# DepressionAnalysisAndClustering
General mental health analysis and getting the unaware, informed of the seriousness of the situation (by the range scale), its consequences and the follow-ups for the betterment.

Some people with depression may try to hide the signs from others, and others might not even realize that they have
depression. Although well-known symptoms such as sadness or hopelessness can be easy to recognize, there are also
other hidden signs of depression. 

So, we intend to build a model and eventually a working web application which would group
people according to their depression or mental states. After clustering people our main objective is to offer them
solutions through an automated chatbot or any other guidance required in any perspective.



